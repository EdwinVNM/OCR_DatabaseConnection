package ocr;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/chart")
public class ChartServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private static final String DB_URL = "jdbc:mysql://localhost:3307/WebDev3_2024";//06/OCR_Project
	private static final String DB_USER = "root";
	private static final String DB_PASSWORD = "";

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("application/json");
		PrintWriter out = response.getWriter();

		String status = request.getParameter("status");

		// Validate the status parameter
		if (status == null || status.isEmpty()) {
			out.print("{\"error\": \"Missing status parameter\"}");
			return;
		}

		// Define allowed statuses in a Set
		Set<String> allowedStatuses = new HashSet<>(Arrays.asList("paid", "partially paid", "unpaid"));

		if (!allowedStatuses.contains(status)) {
			response.setContentType("application/json");
			response.getWriter().write("{\"error\":\"Invalid status parameter.\"}");
			return;
		}

		try {
			// Open database connection
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

			// SQL query to fetch the monthly count and total amount based on status,
			// excluding null invoice_date
			String sql = "SELECT MONTH(STR_TO_DATE(invoice_date, '%d/%m/%Y')) AS month, \n" + "COUNT(*) AS count, \n" + "COALESCE(SUM(total_amount), 0) AS total_amount\n" + "FROM invoice\n" + "WHERE status = ? AND invoice_date IS NOT NULL\n" + "GROUP BY MONTH(STR_TO_DATE(invoice_date, '%d/%m/%Y'));\n";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setString(1, status);
			ResultSet rs = stmt.executeQuery();

			// Building the JSON response
			StringBuilder json = new StringBuilder("[");

			while (rs.next()) {
				int month = rs.getInt("month"); // The month is now a numeric value (1-12)
				int count = rs.getInt("count");
				double totalAmount = rs.getDouble("total_amount");

				// Log the results for debugging purposes
				System.out.println("Month: " + month + ", Count: " + count + ", Total Amount: " + totalAmount);

				json.append("{\"month\":").append(month).append(",\"count\":").append(count).append(",\"total_amount\":").append(totalAmount).append("},");
			}

			if (json.length() > 1) {
				json.setLength(json.length() - 1); // Remove last comma
			}
			json.append("]");

			out.print(json);

			System.out.println("Chart Servlet Query Executed");

			// Clean up resources
			rs.close();
			stmt.close();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
			out.print("{\"error\":\"" + e.getMessage() + "\"}");
		}
	}
}
