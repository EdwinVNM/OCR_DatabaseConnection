package ocr;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/plain");
		PrintWriter out = response.getWriter();

		String username = request.getParameter("user_name");
		String password = request.getParameter("user_password");

		System.out.println("Received Login Request: Username = " + username);

		if (authenticate(username, password)) {
			out.println("success");
		} else {
			out.println("failure");
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Optionally handle GET requests, perhaps return a login page or a message
		response.setContentType("text/plain");
		PrintWriter out = response.getWriter();
		out.println("AUTHENTICATION Servlet Connected");
		System.out.println("AUTHENTICATION Servlet Connected");

	}

	protected boolean authenticate(String name, String password) {
		boolean isAuthenticated = false;
		String query = "SELECT user_password FROM user_login WHERE LOWER(user_name) = LOWER(?)";

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3307/WebDev3_2024", "root", "");

			PreparedStatement ps = conn.prepareStatement(query);
			ps.setString(1, name);
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				String passwordFromDB = rs.getString("user_password");
				if (passwordFromDB.equals(password)) {
					isAuthenticated = true;
				}
			}

			rs.close();
			ps.close();
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return isAuthenticated;
	}
}
