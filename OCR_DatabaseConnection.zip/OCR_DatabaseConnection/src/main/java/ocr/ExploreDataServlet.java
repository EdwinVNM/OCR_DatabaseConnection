package ocr;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/explore")
public class ExploreDataServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private static final String DB_URL = "jdbc:mysql://localhost:3307/WebDev3_2024";//06/OCR_Project
	private static final String DB_USER = "root";
	private static final String DB_PASSWORD = "";

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("application/json");
		PrintWriter out = response.getWriter();

		String field = request.getParameter("field");
		String value = request.getParameter("value");

		// Validate input parameters
		if (field == null || value == null || field.isEmpty() || value.isEmpty()) {
			out.print("Connected from ExploreDataServlet but no parameters passed in");
			return;

		}

		// Whitelist allowed fields to prevent SQL injection
		String allowedFields = "id,customer_name,invoice_date,due_date,total_amount,status";

		if (!allowedFields.contains(field)) {
			out.print("{\"error\":\"Invalid search field.\"}");
			return;

		}

		try {

			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

			// Build SQL query dynamically
			String sql = "SELECT * FROM invoice WHERE " + field + " LIKE ?";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setString(1, "%" + value + "%"); // Allows partial matching

			ResultSet rs = stmt.executeQuery();
			StringBuilder json = new StringBuilder("[");

			while (rs.next()) {
				json.append("{\"id\":").append(rs.getInt("id")).append(",\"customer_name\":\"").append(rs.getString("customer_name")).append("\",\"invoice_date\":\"").append(rs.getString("invoice_date")).append("\",\"due_date\":\"").append(rs.getString("due_date")).append("\",\"total_amount\":").append(rs.getString("total_amount")).append(",\"status\":\"").append(rs.getString("status")).append("\"},");

			}

			if (json.length() > 1) {
				json.setLength(json.length() - 1); // Remove last comma

			}
			json.append("]");

			out.print(json);

			System.out.println("ExploreData Servlet Query Executed");

			rs.close();
			stmt.close();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
			out.print("{\"error\":\"" + e.getMessage() + "\"}");

		}
	}
}
