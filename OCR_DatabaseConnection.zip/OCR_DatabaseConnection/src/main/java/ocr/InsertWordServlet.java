package ocr;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/invoice")
public class InsertWordServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private static final String DB_URL = "jdbc:mysql://localhost:3307/WebDev3_2024";
	private static final String DB_USER = "root";
	private static final String DB_PASSWORD = "";

	// --------------------- GET --------------------- //
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("application/json");
		PrintWriter out = response.getWriter();
		String invoiceId = request.getParameter("id");

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");

			Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

			String sql = invoiceId != null ? "SELECT * FROM invoice WHERE id = ?" : "SELECT * FROM invoice";
			PreparedStatement stmt = conn.prepareStatement(sql);

			if (invoiceId != null) {
				stmt.setInt(1, Integer.parseInt(invoiceId));

			}

			ResultSet rs = stmt.executeQuery();
			StringBuilder json = new StringBuilder("[");

			while (rs.next()) {
				json.append("{\"id\":").append(rs.getInt("id")).append(",\"customer_name\":\"").append(rs.getString("customer_name")).append("\"").append(",\"invoice_date\":\"").append(rs.getString("invoice_date")).append("\"").append(",\"due_date\":\"").append(rs.getString("due_date")).append("\"").append(",\"total_amount\":").append(rs.getString("total_amount")).append(",\"status\":\"").append(rs.getString("status")).append("\"},");

			}

			if (json.length() > 1) {
				json.setLength(json.length() - 1);
			}

			json.append("]");
			out.print(json);

			System.out.println("Connected");

			rs.close();
			stmt.close();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
			out.print("{\"error\":\"" + e.getMessage() + "\"}");

		}
	}

	// --------------------- POST --------------------- //
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/plain");
		PrintWriter out = response.getWriter();

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

			String customer_name = request.getParameter("customer_name");
			String invoice_date = request.getParameter("invoice_date");
			String due_date = request.getParameter("due_date");
			String total_amount = request.getParameter("total_amount");
			String status = request.getParameter("status");

			// LOG received data to verify if Android is sending correctly
			System.out.println("Received Data:");
			System.out.println("Customer Name: " + customer_name);
			System.out.println("Invoice Date: " + invoice_date);
			System.out.println("Due Date: " + due_date);
			System.out.println("Total Amount: " + total_amount);
			System.out.println("Status: " + status);

			String sql = "INSERT INTO invoice (customer_name, invoice_date, due_date, total_amount, status) VALUES (?, ?, ?, ?, ?)";
			PreparedStatement stmt = conn.prepareStatement(sql);

			stmt.setString(1, customer_name);
			stmt.setString(2, invoice_date);
			stmt.setString(3, due_date);
			stmt.setString(4, total_amount); // Ensure this is correctly formatted
			stmt.setString(5, status);

			int rowsInserted = stmt.executeUpdate();
			out.println(rowsInserted > 0 ? "Invoice inserted successfully" : "Failed to insert invoice");

			stmt.close();
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
			out.println("Error: " + e.getMessage());
		}
	}

	// --------------------- PUT --------------------- //
	protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Extract the ID from the URL query parameters (since it's in the URL, not in
		// the body)
		String id = request.getParameter("id");

		// Log the ID for debugging
		System.out.println("Extracted ID from URL: " + id);

		// Log the raw request body
		StringBuilder requestBody = new StringBuilder();
		String line;
		BufferedReader reader = request.getReader();
		while ((line = reader.readLine()) != null) {
			requestBody.append(line);
		}

		// Log the full request body for debugging
		System.out.println("Request Body: " + requestBody.toString());

		// Parse the request body manually (ignoring the ID, since it's already
		// extracted)
		String[] parameters = requestBody.toString().split("&");
		String customerName = null, invoiceDate = null, dueDate = null, totalAmount = null, status = null;

		// Loop through the parameters and assign values (excluding 'id' because it was
		// extracted above)
		for (String param : parameters) {
			String[] keyValue = param.split("=");
			if (keyValue.length == 2) {
				switch (keyValue[0]) {
				case "customer_name":
					customerName = keyValue[1];
					break;
				case "invoice_date":
					invoiceDate = keyValue[1];
					break;
				case "due_date":
					dueDate = keyValue[1];
					break;
				case "total_amount":
					totalAmount = keyValue[1];
					break;
				case "status":
					status = keyValue[1];
					break;
				}
			}
		}

		// Print received parameters for debugging
		System.out.println("Received parameters:");
		System.out.println("customer_name: " + customerName);
		System.out.println("invoice_date: " + invoiceDate);
		System.out.println("due_date: " + dueDate);
		System.out.println("total_amount: " + totalAmount);
		System.out.println("status: " + status);
		System.out.println("id: " + id);

		// Validate the ID
		if (id == null || id.isEmpty()) {
			response.getWriter().println("Error: Missing invoice ID");
			return;
		}

		// Database connection
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

			// Prepare the base SQL query
			StringBuilder sqlBuilder = new StringBuilder("UPDATE invoice SET ");
			List<String> params = new ArrayList<>();
			@SuppressWarnings("unused")
			int paramIndex = 1;

			// Dynamically add non-empty fields to the query
			boolean fieldsToUpdate = false; // Flag to check if any field is being updated

			if (customerName != null && !customerName.isEmpty()) {
				sqlBuilder.append("customer_name=?, ");
				params.add(customerName);
				fieldsToUpdate = true;
			}
			if (invoiceDate != null && !invoiceDate.isEmpty()) {
				sqlBuilder.append("invoice_date=?, ");
				params.add(invoiceDate);
				fieldsToUpdate = true;
			}
			if (dueDate != null && !dueDate.isEmpty()) {
				sqlBuilder.append("due_date=?, ");
				params.add(dueDate);
				fieldsToUpdate = true;
			}
			if (totalAmount != null && !totalAmount.isEmpty()) {
				sqlBuilder.append("total_amount=?, ");
				params.add(totalAmount);
				fieldsToUpdate = true;
			}
			if (status != null && !status.isEmpty()) {
				sqlBuilder.append("status=?, ");
				params.add(status);
				fieldsToUpdate = true;
			}

			// If no fields are to be updated, return an error
			if (!fieldsToUpdate) {
				response.getWriter().println("Error: No fields to update");
				return;
			}

			// Remove the last comma and space
			sqlBuilder.setLength(sqlBuilder.length() - 2);

			// Add the WHERE clause to target the correct invoice by ID
			sqlBuilder.append(" WHERE id=?");
			params.add(id);

			// Prepare the statement
			PreparedStatement stmt = conn.prepareStatement(sqlBuilder.toString());

			// Set parameters for the prepared statement
			for (int i = 0; i < params.size(); i++) {
				stmt.setString(i + 1, params.get(i));
			}

			// Execute the update
			int rowsUpdated = stmt.executeUpdate();
			response.getWriter().println(rowsUpdated > 0 ? "Invoice updated successfully" : "Failed to update invoice");

			stmt.close();
			conn.close();

		} catch (Exception e) {
			// Log the exception to understand the failure reason
			e.printStackTrace();
			response.getWriter().println("Error: " + e.getMessage());
		}
	}

	// --------------------- DELETE --------------------- //
	protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/plain");
		PrintWriter out = response.getWriter();

		try {

			Class.forName("com.mysql.cj.jdbc.Driver");

			Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
			String sql = "DELETE FROM invoice WHERE id=?";
			PreparedStatement stmt = conn.prepareStatement(sql);

			stmt.setInt(1, Integer.parseInt(request.getParameter("id")));

			int rowsDeleted = stmt.executeUpdate();
			out.println(rowsDeleted > 0 ? "Invoice deleted successfully" : "Failed to delete invoice");

			stmt.close();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
			out.println("Error: " + e.getMessage());

		}
	}
}
